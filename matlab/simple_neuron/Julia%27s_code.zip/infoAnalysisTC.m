%%% infoAnalysis streamlined - 26/09/12 JH
%%% Altered for TC stimulation - 29/07/14 JH

% splits trains into blocks
% binarizes trains
% downsamples to bin size
% creates words composed of several bins
% calculates total and noise entropies
% total - noise entropy = mutual information

% Stimulus configuration:
% abcde
% abcde
% abcde
% abcde
% abcde
% Each letter represents one 5 sec ON or OFF train from Niren
% Total entropy is analysed 5 times across each row and averaged together
% Noise entropy is analysed 5 times across each column and averaged together

% 5 sec dummy train which starts trace is also removed before analysis

%%% infoAnalysis2 - 14/03/13 JH

% Now fits a quadratic extrapolation (as in Strong et al., 1998) to
% fractions of the dataset. Instead of callying entropyTotal and
% entropyNoise functions from this script, uniqueFractions and
% noiseFractions are called. These functions split the data into fractions
% (differently for uniques and repeats using splitFractionsT and
% splitFractionsN), then calculate the total and noise entropy (using
% entropyTotal2 and entropyNoise2) for different fractions of the data (all
% fifths, all fourths, all thirds, all halves, and all data), and then fit 
% a quadratic extrapolation (leastSquaresFit2). infoAnalysis2 then fits a
% final quadratic extrapolation to the average value for each fraction,
% across all runs (for total) and all trains (for noise).



%% Start
clear all
addpath('MATLAB functions');
addpath('MATLAB functions\figures');

%% Parameters
threshold   = -10;

blockTime   = 5000;                     % (ms) 
binSize     = 3;                        % (ms) Strong et al used 3 ms bins
wordLength  = 30;                       % (ms) Strong et al used 30 ms long words
timeStep    = 0.05;                     % (ms) 
noTrains    = 5;                        % five different trains
blockSteps  = blockTime/timeStep;
wordBins    = wordLength/binSize;
rateDivisor = (wordBins*binSize/1000);  % divide by this to get entropy rate (bits/sec)
Strong      = 0; % truth index for whether to make Strong fig3 or not

%% Choose Trace
date        = input('date of recording? (yymmdd) '); 
cellNo      = input('cell number? (e.g. 2) '); 
spikeName   = [input('name of file? (e.g. relayStim (TC), stimON_tonic (LGN), dClamp_010) ') '_iClamp']; 'stimON_tonic_iClamp';
spikePath   = ['C:\Users\Elisabeth\Desktop\'...
    'Thalamocortical\Data MATLAB Analysis\data all\'...
    num2str(date) '\cell ' num2str(cellNo) '\'];

%% Load Trace
spike = load([spikePath spikeName '.mat']);

% Binarize spike train:
[timeSpikes, locsAPs, fig_rawSpikes] = binarize(spike.recording, threshold, timeStep);  
% Save memory by using 8 bit numerical:
spikeTrainRaw         = uint8(timeSpikes(1:end)); 

% --- CHECK THRESHOLD --- %
answer = input(['Does this threshold (' num2str(threshold) ') look good? (n=0; y=1) ']);
if answer == 0
    threshold = input('Set new threshold (e.g. -10) ');
    [timeSpikes, locsAPs, fig_rawSpikes] = binarize(spike.recording, threshold, timeStep);
    nextAnswer = input('Better? (n=0; y=1) ');
    if nextAnswer == 1
        spikeTrainRaw = uint8(timeSpikes(1:end)); % save memory by using 8 bit numerical   
    elseif nextAnswer == 0
        error('Go rethink things...');
    end
end

clear spike; % get rid of high memory original spike train

% Remove dummy train (5 sec train at start):
spikeTrainRaw = spikeTrainRaw(blockSteps+1:end);

%% Load Stimulus Train

stimname = 'relayNeuronResponse';%input('stimulus filename? ');
stimpath = ['C:\Users\Elisabeth\Desktop\'...
    'Thalamocortical\Data MATLAB Analysis\data all\'...
    '\Stimulation\'];
stimFile = load([stimpath stimname]);

% Remove dummy train (5 sec train at start):
stimulus = stimFile.stim(blockSteps+1:end);

% Binarize stim train:
[stimTrainRaw, stepInput] = binarizeStim(stimulus);

%% Plot Spike vs Stim Comparison
fig_compare = figure; plot(stimTrainRaw(1:2500000)); % plot whole thing minus dummy
hold on; plot(spikeTrainRaw(1:2500000), 'ro');

%% Trace-Dependent Parameters
trainSteps     = length(spikeTrainRaw);
trainTime      = trainSteps*0.05; % (ms)
noBlocks       = trainTime/blockTime;
spikeFrequency = (sum(spikeTrainRaw))/(noBlocks*blockTime/1000)
stimFrequency  = (sum(stimTrainRaw))/(noBlocks*blockTime/1000)

%% Calculate Information Capacity 
% Max possible info, based on spike frequency (Koch et al, 2006)
Cstim  = maxCapacity(stimFrequency, binSize/1000);
Cspike = maxCapacity(spikeFrequency, binSize/1000);

%% TO LOOK AT INPUT STIM TRAIN RATHER THAN OUTPUT SPIKE TRAIN
% spikeTrainRaw = stimTrainRaw; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 1. Split Spike Train into Blocks:
counter=1;
for i=1:noBlocks
    blockCount = blockSteps;
    spikeBlockRaw      = spikeTrainRaw(counter:counter+blockCount-1);
    % Downsample blocks by bin size:
    spikeBlock         = binData(spikeBlockRaw, timeStep, binSize);
    counter            = counter+blockCount;
    spikeBlocks{i}     = spikeBlock;
end
table.spikes = [spikeBlocks{1:end}];
fig_dotsAll = PlotDotPattern(table.spikes, 'all trains in sequence', timeStep);

%% 2. Calculate Total and Noise Entropy
fig_repeats = [];
cumFreqCountT = zeros(2^wordBins,1);
cumFreqCountN = zeros(2^wordBins,1);
HFractionsT = zeros(5,5); % each row is a different run (of ABCDE), first column is 1/5th for each run, last is all trains
HFractionsN = zeros(5,5); % each row is a different train (of As, Bs etc), first column is 1/5th for each train, last is the whole train
for i = 1:noTrains
    % Define unique and repeat blocks:
    uniquePositions = ((i*noTrains)-(noTrains-1)):1:((i*noTrains)-(noTrains-1))+(noTrains-1);
    repeatPositions = i:noTrains:noBlocks;
    table.unique = table.spikes(:,uniquePositions);
    table.repeat = table.spikes(:,repeatPositions);
%     % Plot responses to repeat blocks:
%     fig_repeat = PlotDotPattern(table.repeat, ['repeat ' num2str(i)], timeStep);
%     fig_repeats = [fig_repeats fig_repeat];
    % Calculate total and noise entropy:
    [HnaiveT{i}, HFractionsT(i,:), frequencyCountT] = uniqueFractions(table.unique, wordBins);
    [HnaiveN{i}, HFractionsN(i,:), frequencyCountN] = noiseFractions(table.repeat, wordBins);
    cumFreqCountT = cumFreqCountT+frequencyCountT;
    cumFreqCountN = cumFreqCountN+frequencyCountN;
end

% % OPTIONAL: Extrapolation based on all runs (for total) or trains (for noise): %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% meanFractionsT = mean(HFractionsT);
% [cfun,gof,percentCorrectionT,Hinf,secondOrder] = fitLeastSquares2(meanFractionsT,1,2);
% meanFractionsN = mean(HFractionsN);
% [cfun,gof,percentCorrectionN,Hinf,secondOrder] = fitLeastSquares2(meanFractionsN,2,2);
% percentCorrectionT
% percentCorrectionN

% strongFig2(cumFreqCountT); hold on; title('TOTAL');
% strongFig2(cumFreqCountN); hold on; title('NOISE');
noWordsTotal = sum(cumFreqCountT>1);
noWordsNoise = sum(cumFreqCountN>1);

%% 3. Calculate Mutual Information
% Average total entropies:
totalEntropies = [HnaiveT{1}(end),HnaiveT{2}(end),HnaiveT{3}(end),HnaiveT{4}(end),HnaiveT{5}(end)];
entropyMaxT = mean(totalEntropies);
sT = std(totalEntropies);
% Averagey noise entropies:
noiseEntropies = [HnaiveN{1}(end),HnaiveN{2}(end),HnaiveN{3}(end),HnaiveN{4}(end),HnaiveN{5}(end)];
entropyMaxN = mean(noiseEntropies);
sN = std(noiseEntropies);
% Mutual information (bits/sec):
info    = (entropyMaxT-entropyMaxN)/rateDivisor; % entropies are in bits per time bin, so divide by size of time bin to get bits/sec

%% OPTIONAL:
% % write results of entropy per train into spreadsheet
% realNo = input('Overall cell number? ');
% excelpath = 'C:\Documents and Settings\Julia\My Documents\Projects\Visual Synapses\Analysis\';
% workbook  = 'MasterData.xlsx';
% worksheet = 'Entropy';
% rangeNo   = num2str(realNo+5);
% totalEntropyRates = totalEntropies/rateDivisor;
% noiseEntropyRates = noiseEntropies/rateDivisor;
% xlswrite([excelpath workbook],totalEntropyRates,worksheet,['B' rangeNo ':F' rangeNo]);
% xlswrite([excelpath workbook],noiseEntropyRates,worksheet,['K' rangeNo ':O' rangeNo]);

%% OPTIONAL: Strong et al Fig 3
% % MIGHT NOT WORK IN INFOANALYSIS2 !!
% % Entropy rate vs 1/word length
% % NOTE: do this INSTEAD of  sections 2 & 3
% Strong = 1; % truth index for deciding what to save (below)
% inputTable = table.spikes;
% fig_entropy = strongFig3(inputTable, binSize, noTrains, noBlocks);

%% Save Numbers
if Strong == 1
else
    answerInfo.stimFrequency  = stimFrequency;   % Hz
    answerInfo.spikeFrequency = spikeFrequency;  % Hz
    answerInfo.info           = info;      % bits/sec
    answerInfo.totalH         = entropyMaxT/rateDivisor;
    answerInfo.noiseH         = entropyMaxN/rateDivisor;
    answerInfo.capacityStim   = Cstim;           % bits/sec
    answerInfo.capacitySpike  = Cspike;          % bits/sec
    answerInfo.threshold      = threshold;
    save([spikePath 'answerInfo_' spikeName], 'answerInfo'); 
    % Print out
    disp(spikeName);
    disp(answerInfo);
end

%% Save Figures
if Strong == 1
    % When making Strong fig3:
    hgsave([fig_rawSpikes fig_compare fig_dotsAll fig_entropy],...
    [spikePath 'figs_Info_' spikeName '.fig']);
else
    % When not making Strong fig3:
    hgsave([fig_rawSpikes fig_compare fig_dotsAll fig_repeats],...
    [spikePath 'figs_Info_' spikeName '.fig']);
end

%% Save binarized train

save([spikePath 'binarizedTrain', spikeName], 'spikeTrainRaw');

%% End
rmpath('MATLAB functions\figures');
rmpath('MATLAB functions');

