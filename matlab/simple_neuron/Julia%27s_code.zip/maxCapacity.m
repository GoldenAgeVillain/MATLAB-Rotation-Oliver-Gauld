function [C] = maxCapacity(R, deltaT);

% Perge et al (2012) : max info capacity of firing neuron

% "For neurons firing action potentials at a rate R, the maximum amount of
% information that could be conveyed per unit time in the absence of noise
% and spike correlations (i.e. the "capacity" in bits/second) is (formula 
% below), where R is the firing rate and deltaT is the time bin used to 
% compute information (typically, the refractory period) (Koch et al,
% 2006)"

% In fact, noise (measured from the variability of responses to repeated 
% stimulus presentations)and correlations (measured from responses to long
% movies) reduce the information rate from this theoretical maximum.

% % To use on its own:
% R = input('Firing rate? '); % (Hz) firing rate
% deltaT = 0.003; % (sec) time bin

C = -[R*deltaT*log2(R*deltaT) + ((1-(R*deltaT))*log2(1-(R*deltaT)))]/deltaT;

disp(['C = ' num2str(C) ' bits / sec'])

% In the guinea pig retina, there is an orderly relation between firing
% rate and information rate (formula below), where alpha is a fixed
% constant for all retinal ganglion cell types and all stimulus classes,
% and C is teh capacity at firing rate R (Koch et al, 2006)

% I = alpha*C*(R, deltaT)

